// JavaScript Document
var brandlist = new Array("Porsche","Volkswagen","Audi","Bmw");

//Counter to limit 10 customer at one time
var count = 0;

// (L) update the numbers
var clients_served = 0;
var cars_sold = 0;
var amount = 0;
var brandcost = new Array(72500, 23930, 31260, 43990);
var clientInshop = false ;

function newClient()
{
	var preference = Math.floor((Math.random()*4));
	var time = Math.floor((Math.random()*10000)+1);
	
//check to limit to max 10	
if (count <10)
{
	var client = Math.floor((Math.random()*10)+1);
	$("#clients_queue").append('<div class="client client_' + client + ' choice_' + brandlist[preference] + '"><span class= "preference">' + brandlist[preference] + '</span></div>');
	
//Add one for each newly created customer
count += 1;	
	
// (C) Make the first client draggable and revert if not dropped.
	$('#clients_queue > .client:first').draggable({ revert: true , zIndex : 100}); 
}	
	setTimeout(function() {newClient();},time);		
}
	function dropclient($this, ui){
		if(clientInshop) {
			count > 10 ;
		$this.not(':has(".client")').each(function() {
		$(this).append(ui.draggable.css({float: 'left'}));
		ui.draggable.position({of: $(this), my: 'left top', at: 'left top'});
			});	 
		}
		else {
		$this.not(':has(".client")').each(function() {
		$(this).append(ui.draggable.css({float: 'left'}));
		ui.draggable.position({of: $(this), my: 'left top', at: 'left top'});
		
		count -= 1;
		newClient();
		ui.draggable.addClass('selected');
		clientInshop = true;
		});
		}
	} //End of dropclient()

function dropclient2($this, ui)
{
	$this.not(':has(".client")').each(function()
{								 
	$this.append(ui.draggable.css({float: 'left'}));
	ui.draggable.position({of: $(this), my: 'left top', at: 'left top'});

if (!ui.draggable.hasClass('selected'))
{
	count -= 1;
	newClient();
}

});														  
} //End of dropclient2()

function removeclient(ui, where)
{
	ui.draggable.animate( { top: where}					 
).fadeOut (function()
          {
	ui.draggable.remove();
          }
); //End of fadeOut	
clientInshop = false;	   
} //End of removeclient()

function calcost(ui)
{
	
if (ui.draggable.hasClass('choice_Porsche'))
{
	return brandcost[0];
}

else if (ui.draggable.hasClass('choice_Volkswagen'))
{
	return brandcost[1];
}	
	
else if (ui.draggable.hasClass('choice_Audi'))
{
	return brandcost[2];
}	
	
else if (ui.draggable.hasClass('choice_Bmw'))
{
	return brandcost[3];
}	

} //End of calcost()

function update()
{
	$('#clients_served').text(clients_served + ' clients');
	$('#cars_sold').text(cars_sold + ' cars');
	$('#amount').text('S$' + amount);
} //End of update

$("document").ready(function(e)
{
	newClient();
	update();

// (F) Make porsche droppable.
$('#porsche .car').droppable(
{
	accept: '.choice_Porsche',
		
	drop: function(e, ui)
	{
		dropclient($(this), ui);
		$(this).addClass('sell');
	},
	out: function (e, ui) {  
		$(this).removeClass('sell');
	}
}
); //end of droppable porsche

// (F) Make porsche droppable.
$('#volkswagen .car').droppable(
{
	accept: '.choice_Volkswagen',
		
	drop: function(e, ui)
	{
		dropclient($(this), ui);
		$(this).addClass('sell');
	}
}
); //end of droppable volkswagen

// (F) Make audi droppable.
$('#audi .car').droppable(
{
	accept: '.choice_Audi',
		
	drop: function(e, ui)
	{
		dropclient($(this), ui);
		$(this).addClass('sell');
	}
}
); //end of droppable audi	
	
$('#bmw .car').droppable(
{
	accept: '.choice_Bmw',
		
	drop: function(e, ui)
	{
		dropclient($(this), ui);
		$(this).addClass('sell');
	}
}
); //end of droppable Bmw
	
//For the client to Exit
$('#exit div').droppable(
{
	accept: '.client',	
	drop: function(e, ui)
{
	dropclient2($(this), ui);
	removeclient(ui, -80);

	var audioElement =  new Audio('music/Microsoft Windows XP Shutdown - Sound Effect (HD).mp3');
	audioElement.play();
}
	
}
); //end of droppable for exit

//For the client to go cashier
	$('#cashier div').droppable(
{
	accept: '.client.selected',
	drop: function(e, ui)
{
	document.getElementById("dialog").style.display = "block";
	dropclient2($(this), ui);

$('#dialog').dialog ({
buttons: {
	"Yes": function()
{
clients_served += 1;
cars_sold += 1;
amount += calcost(ui);
update();

removeclient(ui, -150);
$( this ).dialog( "close" );

$('.sell img').attr('src', 'images/Sold.jpg');
$('.sell img').removeClass("sell").toggleClass("sold").toggleClass("car");
$('.sold').droppable( { disabled: true } );

var audioElement = new Audio('music/Cash_Register_(Kaching)_-_Sound_Effect_(HD).mp3');
audioElement.play();
},

"No": function()
{	
removeclient(ui, -350);
$( this ).dialog( "close" );
$('.sell').removeClass("sell")

var audioElement = new Audio('music/Microsoft Windows XP Shutdown - Sound Effect (HD).mp3');
audioElement.play();
}
},

close: function()
{
	removeclient(ui, -350);
}

});

}
}
); //end of droppable for cashier	
		
}); //end of droppable ready